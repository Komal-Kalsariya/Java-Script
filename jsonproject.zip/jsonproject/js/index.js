import navBar from "../components/navbar.js"


 navBar
document.getElementById("navbar").innerHTML=navBar()